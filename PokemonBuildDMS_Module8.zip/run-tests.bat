@echo off
cd /d "%~dp0"
if not exist build mkdir build
javac -encoding UTF-8 -source 8 -target 8 -d build src\dms\*.java
if errorlevel 1 exit /b 1
javac -encoding UTF-8 -source 8 -target 8 -cp "build;lib\*" -d build test\dms\*.java
if errorlevel 1 exit /b 1
java -cp "build;lib\*" org.junit.runner.JUnitCore dms.DmsTests
pause
