package dms;
import org.junit.Test;
import static org.junit.Assert.*;
import java.time.LocalDate;
import java.util.Scanner;
/**
 * Adriel Portillo Perez | CEN 3024C | October 24, 2026
 * Class: DmsTests
 * Verifies positive and negative CRUD, file, calculation and console cases.
 * Every test receives a fresh repository so results do not depend on test order.
 */
public class DmsTests {
 private final BuildValidator v=new BuildValidator();
 private final PokemonBuildRepository repo=new PokemonBuildRepository(v);
 private final BuildFileService files=new BuildFileService(v);
 private final TeamReadinessCalculator calc=new TeamReadinessCalculator(v);
 /**
  * build constructs a known selected test record.
  * @param id unique test identifier
  * @return a valid record with deterministic values
  */
 private PokemonBuild build(int id) { return new PokemonBuild(id,"Garchomp","Dragon","Ground","Sweeper",600,20,true,LocalDate.of(2026,10,13)); }
 /**
  * app constructs a console controller with simulated user input.
  * @param input newline-separated user entries
  * @return a controller using the test repository
  */
 private PokemonBuildApp app(String input) { return new PokemonBuildApp(repo,files,calc,new Scanner(input)); }
 /**
  * addValidObject verifies addValidObject behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void addValidObject() throws Exception { assertTrue(repo.addBuild(build(1))); assertEquals(1, repo.count()); assertEquals("Garchomp", repo.findBuildById(1).get().getSpeciesName()); }
 /**
  * addDuplicateRejected verifies addDuplicateRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void addDuplicateRejected() throws Exception { repo.addBuild(build(1)); assertFalse(repo.addBuild(build(1))); assertEquals(1, repo.count()); }
 /**
  * addNullRejected verifies addNullRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void addNullRejected() throws Exception { assertFalse(repo.addBuild(null)); assertEquals(0, repo.count()); }
 /**
  * removeExistingObject verifies removeExistingObject behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void removeExistingObject() throws Exception { repo.addBuild(build(1)); assertTrue(repo.removeBuild(1)); assertFalse(repo.findBuildById(1).isPresent()); assertEquals(0,repo.count()); }
 /**
  * removeMissingObject verifies removeMissingObject behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void removeMissingObject() throws Exception { repo.addBuild(build(1)); assertFalse(repo.removeBuild(999)); assertEquals(1,repo.count()); }
 /**
  * updateExistingObject verifies updateExistingObject behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void updateExistingObject() throws Exception { repo.addBuild(build(1)); PokemonBuild changed=build(1); changed.setUsageRate(30); assertTrue(repo.updateBuild(changed)); assertEquals(30,repo.findBuildById(1).get().getUsageRate(),0); }
 /**
  * updateMissingObject verifies updateMissingObject behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void updateMissingObject() throws Exception { assertFalse(repo.updateBuild(build(999))); assertEquals(0,repo.count()); }
 /**
  * updateDuplicateIdRejected verifies updateDuplicateIdRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void updateDuplicateIdRejected() throws Exception { repo.addBuild(build(1)); repo.addBuild(build(2)); assertFalse(repo.updateBuild(1,build(2))); assertEquals(2,repo.count()); assertTrue(repo.containsId(1)); }
 /**
  * updateAllNineFields verifies updateAllNineFields behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void updateAllNineFields() throws Exception { repo.addBuild(build(1)); PokemonBuild b=new PokemonBuild(2,"Lucario","Fighting","Steel","Support",525,30,false,LocalDate.of(2026,10,14)); assertTrue(repo.updateBuild(1,b)); assertFalse(repo.containsId(1)); assertEquals(b.toCsvLine(),repo.findBuildById(2).get().toCsvLine()); }
 /**
  * displayStoredObjects verifies displayStoredObjects behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void displayStoredObjects() throws Exception { repo.addBuild(build(1)); java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream(); java.io.PrintStream old=System.out; try { System.setOut(new java.io.PrintStream(bytes)); assertEquals(1,app("").displayBuilds(repo.getAllBuilds())); } finally { System.setOut(old); } assertTrue(bytes.toString().contains("Garchomp")); }
 /**
  * displayEmptyObjects verifies displayEmptyObjects behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void displayEmptyObjects() throws Exception { assertEquals(0,app("").displayBuilds(repo.getAllBuilds())); }
 /**
  * openValidSampleFile verifies openValidSampleFile behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void openValidSampleFile() throws Exception { assertTrue(files.isReadableFile("data.txt")); assertEquals(20,files.loadFromCsv("data.txt",repo)); assertEquals(20,repo.count()); assertTrue(files.getSkippedLines().isEmpty()); }
 /**
  * openMissingFileRejected verifies openMissingFileRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void openMissingFileRejected() throws Exception { assertFalse(files.isReadableFile("missing-unit-test-file.txt")); assertThrows(java.io.IOException.class, () -> files.loadFromCsv("missing-unit-test-file.txt",repo)); assertEquals(0,repo.count()); }
 /**
  * openBlankFileRejected verifies openBlankFileRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void openBlankFileRejected() throws Exception { assertThrows(java.io.IOException.class, () -> files.loadFromCsv(" ",repo)); }
 /**
  * openDirectoryRejected verifies openDirectoryRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void openDirectoryRejected() throws Exception { assertThrows(java.io.IOException.class, () -> files.loadFromCsv(".",repo)); }
 /**
  * malformedRowsSkipped verifies malformedRowsSkipped behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void malformedRowsSkipped() throws Exception { java.nio.file.Path p=java.nio.file.Files.createTempFile("dms-test", ".txt"); try { java.nio.file.Files.write(p,java.util.Arrays.asList(build(1).toCsvLine(),"bad,row", "2,ABDCE,Dragon,Ground,Sweeper,600,20,T,2026-10-13")); assertEquals(1,files.loadFromCsv(p.toString(),repo)); assertEquals(2,files.getSkippedLines().size()); } finally { java.nio.file.Files.deleteIfExists(p); } }
 /**
  * customScoreKnownTeam verifies customScoreKnownTeam behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void customScoreKnownTeam() throws Exception { double expected=600.0/720*40+2.0/18*25+5+20.0/100*15; assertEquals(expected,calc.calculateScore(java.util.Arrays.asList(build(1))),0.000001); }
 /**
  * customScoreSampleTeam verifies customScoreSampleTeam behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void customScoreSampleTeam() throws Exception { files.loadFromCsv("data.txt",repo); assertEquals(64.4477777778,calc.calculateScore(repo.getAllBuilds()),0.000001); }
 /**
  * customScoreEmptyRejected verifies customScoreEmptyRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void customScoreEmptyRejected() throws Exception { assertThrows(IllegalArgumentException.class, () -> calc.calculateScore(java.util.Collections.emptyList())); }
 /**
  * customScoreSevenRejected verifies customScoreSevenRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void customScoreSevenRejected() throws Exception { java.util.List<PokemonBuild> team=new java.util.ArrayList<>(); for(int i=1;i<=7;i++) team.add(build(i)); assertThrows(IllegalArgumentException.class, () -> calc.calculateScore(team)); }
 /**
  * customScoreDuplicateRejected verifies customScoreDuplicateRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void customScoreDuplicateRejected() throws Exception { assertThrows(IllegalArgumentException.class, () -> calc.calculateScore(java.util.Arrays.asList(build(1),build(1)))); }
 /**
  * seventhTeamSelectionRejected verifies seventhTeamSelectionRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void seventhTeamSelectionRejected() throws Exception { for(int i=1;i<=6;i++) assertTrue(repo.addBuild(build(i))); assertFalse(repo.addBuild(build(7))); assertEquals(6,repo.count()); }
 /**
  * booleanShortcutsAccepted verifies booleanShortcutsAccepted behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void booleanShortcutsAccepted() throws Exception { assertTrue(v.parseBoolean(" T ").get()); assertFalse(v.parseBoolean("f").get()); assertTrue(v.parseBoolean("true").get()); assertFalse(v.parseBoolean("FALSE").get()); }
 /**
  * booleanInvalidRejected verifies booleanInvalidRejected behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void booleanInvalidRejected() throws Exception { assertFalse(v.parseBoolean("maybe").isPresent()); assertFalse(v.parseBoolean("").isPresent()); }
 /**
  * speciesCatalogValidation verifies speciesCatalogValidation behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void speciesCatalogValidation() throws Exception { assertTrue(v.isValidSpeciesName("lucario")); assertFalse(v.isValidSpeciesName("ABDCE")); assertFalse(v.isValidSpeciesName("123")); assertFalse(v.isValidSpeciesName(null)); }
 /**
  * numberedMenusAndRetry verifies numberedMenusAndRetry behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void numberedMenusAndRetry() throws Exception { assertTrue(app("121\n123\nABDCE\n21\n99\n16\n0\n2\n525\n5\nf\n2026-10-13\n").addBuildFlow()); PokemonBuild b=repo.findBuildById(121).get(); assertEquals("Umbreon",b.getSpeciesName()); assertEquals("Dark",b.getPrimaryType()); assertEquals("Wall",b.getRole()); assertFalse(b.isSelectedForTeam()); }
 /**
  * invalidMenuRetry verifies invalidMenuRetry behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void invalidMenuRetry() throws Exception { assertEquals(2,app("abc\n9\n\n2\n").readMenuChoice()); }
 /**
  * invalidNumericAndDates verifies invalidNumericAndDates behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void invalidNumericAndDates() throws Exception { assertFalse(v.parseDoubleInRange("NaN",0,100).isPresent()); assertFalse(v.parseIntInRange("999999999999",1,720).isPresent()); assertFalse(v.parseDate("2026-02-30").isPresent()); assertFalse(v.parseDate("2999-01-01").isPresent()); }
 /**
  * invalidSetterPreservesData verifies invalidSetterPreservesData behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void invalidSetterPreservesData() throws Exception { PokemonBuild b=build(1); assertFalse(b.setUsageRate(-1)); assertFalse(b.setSpeciesName("ABDCE")); assertFalse(b.setTypes("Dragon","Dragon")); assertEquals(20,b.getUsageRate(),0); assertEquals("Garchomp",b.getSpeciesName()); }
 /**
  * exitRequested verifies exitRequested behavior and resulting state.
  * Arguments: none.
  * @return nothing; JUnit assertions report a failure for an unexpected result
  */
 @Test public void exitRequested() throws Exception { assertTrue(app("abc\n0\n").run()); }
}
