# Pokemon Build DMS — Module 8
Open this folder in IntelliJ and select an installed JDK 8 or newer. Source: src/dms. Tests: test/dms/DmsTests.java. Included lib files supply JUnit 4.13.2 and Hamcrest 1.3 without downloads.

Run Main.java for the application. Enter 1, data.txt, 2, 6 to load/display/calculate. Working directory must be the project root.

Run DmsTests using its green run arrow or the supplied DmsTests configuration. Windows alternative: run-tests.bat (requires javac on PATH). Expected: OK (30 tests). Negative tests PASS when invalid input is correctly rejected.

Executable: java -jar dist/PokemonBuildDMS.jar from this folder.

Species are restricted to the 26 names in BuildValidator.getSpecies(), including all 20 sample species plus Umbreon, Lucario, Pikachu, Absol, Maushold, and Volcarona. This is a supported catalog, not the entire Pokedex. Types and roles use numbered menus; listed names also work. Boolean questions accept T/F and true/false, ignoring case.

JUnit: https://junit.org/junit4/ (Eclipse Public License 1.0). Hamcrest: https://hamcrest.org/ (BSD license). Libraries are test-only and are excluded from the application JAR.
